import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.Label;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;


public class Client extends Application {
    private int image = 0;
    private VBox root;
    private javafx.scene.control.TextField userText;
    private TextArea chatWindow;
    private Scene scene;
    private ObjectOutputStream output;
    private ObjectInputStream input;
    private String message = "";
    private static String serverIP;
    private Socket connection;
    private Group group = new Group();
    private int first = 0;
    private String name;

    public static void main(String[] args) {
        serverIP = "127.0.0.1";
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                startRunning();
            }
        });
        Label label = new Label("Enter your name");
        label.setFont(Font.font(16));
        label.relocate(200,130);

        userText = new TextField();
        chatWindow = new TextArea();
        root = new VBox(20, userText);




        userText.setOnKeyReleased(event ->
        {
            if (event.getCode() == KeyCode.ENTER){
                if (first == 0){
                    name = userText.getText();
                    userText.setText("");
                    first = 1;
                    userText.setEditable(false);
                    root.getChildren().remove(label);
                    root.getChildren().addAll(chatWindow);
                    primaryStage.setTitle(name);
                    thread.start();
                }else {
                    sendMessage(userText.getText());
                    userText.setText("");
                }
            }
        });
            root.getChildren().addAll(label);
            chatWindow.setPrefHeight(400);
            scene = new Scene(root, 400, 400,Color.rgb(175,166,143));
            primaryStage.setScene(scene);

            primaryStage.show();


    }
    public void startRunning(){
        try{
            connectToServer();
            setupStreams();
            whileChatting();
        }catch(Exception e){
        }finally {
            closeConnection();
        }
    }

    private void connectToServer() throws IOException{
        connection = new Socket(InetAddress.getByName(serverIP), 6789);
        showMessage("Connection Established!");
    }

    private void setupStreams() throws IOException{
        output = new ObjectOutputStream(connection.getOutputStream());
        output.flush();
        input = new ObjectInputStream(connection.getInputStream());
    }

    private void whileChatting() throws IOException{
        ableToType(true);
        do{
            try{
                if (image == 0 ){
                    message = (String) input.readObject();
                    showMessage(message);
                    if (message.indexOf("send image")!= -1){
                        image = 1;
                    }
                }else if (image == 1){
                    image = 0;

                    byte[] sizeAr = new byte[4];
                    input.read(sizeAr);
                    int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();

                    byte[] imageAr = new byte[size];
                    input.read(imageAr);

                    BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageAr));

                    ImageIO.write(image, "jpg", new File("image.jpg"));

                    Image image1 = new Image("file:image.jpg");
                    ImageView iv = new ImageView();
                    iv.setFitWidth(100);
                    iv.setFitHeight(80);
                    iv.setImage(image1);
                    Platform.runLater(
                            new Runnable(){
                                public void run(){

                                    root.getChildren().addAll(iv);
                                }
                            }
                    );
                }
            }catch(Exception e){}
        }while(!message.equals(name+" - END"));
    }

    private void closeConnection(){
        showMessage("Closing the connection!");
        ableToType(false);
        try{
            output.close();
            input.close();
            connection.close();
        }catch(IOException ioException){
            ioException.printStackTrace();
        }
    }

    private void sendMessage(String message){
        try{
            output.writeObject(name+" - " + message);
            output.flush();
            showMessage(name+" - " + message);
        }catch(IOException ioException){}
    }

    private void showMessage(final String message){
        Platform.runLater(
                new Runnable(){
                    public void run(){
                        chatWindow.appendText("\n"+message+"\n");
                    }
                }
        );
    }

    private void ableToType(final boolean tof){
        Platform.runLater(
                new Runnable(){
                    public void run(){
                        userText.setEditable(tof);
                    }
                }
        );
    }
}