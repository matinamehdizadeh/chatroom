import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;

public class Serv extends Application {
    private String name;
    private int first = 0;
    private VBox root;
    private TextField userText;
    private TextArea chatWindow;
    private ObjectOutputStream output;
    private ObjectInputStream input;
    private ServerSocket server;
    private Socket connection;
    Scene scene;

    public static void main(String[] args) {
        launch(args);

    }

    public void startRunning(){
        try{
            server = new ServerSocket(6789, 100);
            while(true){
                try{
                    waitForConnection();
                    setupStreams();
                    whileChatting();
                }catch(EOFException eofException){
                } finally{
                    closeConnection();
                }
            }
        } catch (IOException ioException){}
    }
    private void waitForConnection() throws IOException{
        showMessage(" Waiting for someone to connect...");
        connection = server.accept();
    }

    private void setupStreams() throws IOException{
        output = new ObjectOutputStream(connection.getOutputStream());
        output.flush();

        input = new ObjectInputStream(connection.getInputStream());
    }
    private void whileChatting() throws IOException{
        String message = " You are now connected! ";
        sendMessage(message);
        ableToType(true);
        do{
            try{
                message = (String) input.readObject();
                showMessage( message);
            }catch(Exception e){}
        }while(!message.equals(name +" - END"));
    }

    public void closeConnection(){
        showMessage("Closing Connections... ");
        ableToType(false);
        try{
            output.close();
            input.close();
            connection.close();
        }catch(IOException ioException){ }
    }

    private void sendMessage(String message){
        try{
            if (message.matches("send image")){
                output.writeObject(name + " - " + message);
                output.flush();
                showMessage(name + " - " + message);

                BufferedImage image = ImageIO.read(new File("image.jpg"));

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ImageIO.write(image, "jpg", byteArrayOutputStream);

                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                output.write(size);
                output.write(byteArrayOutputStream.toByteArray());
                output.flush();
                Image image1 = new Image("file:image.jpg");
                ImageView iv = new ImageView();
                iv.setFitWidth(100);
                iv.setFitHeight(80);
                iv.setImage(image1);
                Platform.runLater(
                        new Runnable(){
                            public void run(){

                                root.getChildren().addAll(iv);
                            }
                        }
                );

            }else {
                output.writeObject(name + " - " + message);
                output.flush();
                showMessage(name + " - " + message);
            }
        }catch(IOException ioException){ }
    }

    private void showMessage(final String text){
        Platform.runLater(
                new Runnable(){
                    public void run(){
                        chatWindow.appendText("\n"+text+"\n");
                    }
                }
        );
    }

    private void ableToType(final boolean tof){
        Platform.runLater(
                new Runnable(){
                    public void run(){
                        userText.setEditable(tof);
                    }
                }
        );
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                startRunning();
            }
        });
        javafx.scene.control.Label label = new Label("Enter your name");
        label.setFont(Font.font(16));
        label.relocate(200,130);

        userText = new TextField();
        chatWindow = new TextArea();
        root = new VBox(20, userText);




        userText.setOnKeyReleased(event ->
        {
            if (event.getCode() == KeyCode.ENTER){
                if (first == 0){
                    name = userText.getText();
                    userText.setText("");
                    first = 1;
                    userText.setEditable(false);
                    thread.start();
                    root.getChildren().remove(label);
                    root.getChildren().addAll(chatWindow);
                    primaryStage.setTitle(name);
                }else {
                    sendMessage(userText.getText());
                    userText.setText("");
                }
            }
        });
        root.getChildren().addAll(label);
        chatWindow.setPrefHeight(400);
        scene = new Scene(root, 400, 400);
        primaryStage.setScene(scene);

        primaryStage.show();


    }
}